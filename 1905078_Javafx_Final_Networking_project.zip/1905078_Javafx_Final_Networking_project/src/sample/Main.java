package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import util.NetworkUtil;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class Main extends Application {
    public String str;
    private Stage stage = new Stage();
    private NetworkUtil networkUtil;
    public static List<Player> playerList = new ArrayList<>();
    public static List<Player> playermList = new ArrayList<>();

    public Stage getStage() {
        return stage;
    }
    public NetworkUtil getNetworkUtil() {
        return networkUtil;
    }
    public static void setPlayerList(List<Player> playerList) { Main.playerList = playerList; }
    public static List<Player> getPlayerList() {
        return playerList;
    }

    public static void setPlayermList(List<Player> playerList) { Main.playermList = playerList; }
    public static List<Player> getPlayermList() {
        return playermList;
    }

    @Override
    public void start(Stage primaryStage) throws Exception{
        stage = primaryStage;
        connecttoServer();
        Show_welcome();

    }

    private void connecttoServer() throws IOException {
        String serverAddress = "127.0.0.1";
        int serverPort = 22222;
        networkUtil = new NetworkUtil(serverAddress, serverPort);
        new ReadThread(this);
    }

    public void Show_welcome() throws Exception {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("FXML/welcome.fxml"));
        Parent root = loader.load();

        // Loading the controller
        WelcomePage controller = loader.getController();
        //controller.init(userName);
        controller.setMain(this);
        stage.setTitle("Welcome");
        stage.setScene(new Scene(root, 1000,800));
        stage.show();
    }

    public static void main(String[] args)  {
        launch(args);
    }

    public void showLogin() throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("FXML/Login.fxml"));
        Parent root = loader.load();

        // Loading the controller
        LoginPage controller = loader.getController();
        //controller.init(userName);
        controller.setMain(this);
        stage.setTitle("Login");
        stage.setScene(new Scene(root, 900,600));
        stage.show();

    }

    public void showAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Incorrect Credentials");
        alert.setHeaderText("Wrong Info");
        alert.setContentText("No such Club with this name");
        alert.showAndWait();
    }

    public void showAlert2() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("ERROR!");
        alert.setHeaderText("NO CLUB NAME");
        alert.setContentText("You have to take input of a club name");
        alert.showAndWait();
    }



    public void ShowTable(String clubname) throws Exception {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("FXML/tableview.fxml"));
        Parent root = loader.load();

        // Loading the controller
        TableViewController controller = loader.getController();
        controller.init(clubname);
        str = controller.name;
        controller.load();
        controller.setMain(this);
        stage.setTitle("Player List");
        stage.setScene(new Scene(root));
        stage.show();
    }

    public void ShowCountryTable(String clubname, List<Player> playerList) throws Exception {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("FXML/countrywiseplayercount.fxml"));
        Parent root = loader.load();

        // Loading the controller
        CounterTableView controller = loader.getController();
        controller.init(clubname,playerList);
        controller.load();
        controller.setMain(this);
        stage.setTitle("Country wise Player count");
        stage.setScene(new Scene(root));
        stage.show();
    }

    public void ShowMarketPlace(String clubname) throws Exception {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("FXML/MarketPlace.fxml"));
        Parent root = loader.load();

        // Loading the controller
        MarketController controller = loader.getController();
        controller.init(clubname);
        controller.load();
        controller.setMain(this);
        stage.setTitle("Market Place");
        stage.setScene(new Scene(root));
        stage.show();
    }

}
