package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import util.LoginDTO;

import java.io.IOException;
import java.net.URL;
import java.util.*;

public class CounterTableView{
    private static List<Country> Country_List = new ArrayList<>();
    private String clubname;
    @FXML
    private Button BACKFROMCOUNT;

    @FXML
    private Label label;
    @FXML
    private TableView<Country> table;

    @FXML
    private TableColumn<Country, Integer> PLAYERCOL;

    @FXML
    private TableColumn<Country, String> COUNTRYCOL;
    private Main main;

    void setMain(Main main) {
        this.main = main;
    }
    private boolean init = true;

    void init(String msg, List<Player> playerList) throws Exception {
        clubname = msg;
        for(Player pl:playerList){
            boolean m=false;
            for(Country cl:Country_List){
                if(pl.getCountry().equalsIgnoreCase(cl.get_country())){
                    m=true;
                    cl.set_count(cl.get_count()+1);
                }
            }
            if(!m){
                Country cl=new Country(pl.getCountry(),1);
                Country_List.add(cl);
            }
        }
    }
    ObservableList<Country> countryObservableList;
    private void Columns() {
        COUNTRYCOL.setCellValueFactory(cellData -> cellData.getValue().country_Property());

        PLAYERCOL.setCellValueFactory(cellData -> cellData.getValue().count_Property().asObject());
    }

    public void load() {
        if (init) {
           Columns();
            init = false;
        }

       countryObservableList = FXCollections.observableArrayList(Country_List);

        table.setEditable(true);
        table.setItems(countryObservableList);
    }
    @FXML
    void backcountOnAction(ActionEvent event) throws Exception {
      main.ShowTable(main.str);
      Country_List.clear();
    }

}
