package sample;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.util.ArrayList;
import java.util.List;

public class Country {
    private SimpleStringProperty country;
    private SimpleIntegerProperty count;

    public Country(){

    }
    Country(String country,int count) {
        this.country = new SimpleStringProperty(country);
        this.count = new SimpleIntegerProperty(count);
    }
    public void set_country(String country) {
        this.country.set(country);
    }
    public final StringProperty country_Property() {
        return this.country;
    }

    public final String get_country() {
        return this.country_Property().get();
    }

    public void set_count(int count) {
        this.count.set(count);
    }

    public final IntegerProperty count_Property() {
        return this.count;
    }

    public final Integer get_count() {
        return this.count_Property().get();
    }

}
