package sample;

import java.util.ArrayList;
import java.util.List;

public class SeachMethods {
    public static List<Player> SearchingPlayerName(String plName,List<Player> player_List) {
        List<Player> newplayerlist = new ArrayList<>();
        for (Player t : player_List) {
            if(plName.equalsIgnoreCase(t.getName()))
            {
                newplayerlist.add(t);
                break;
            }
        }
        return newplayerlist;
    }

    public static List<Player> SearchingPosition(String position, List<Player> player_List) {
        List<Player> newplayerlist = new ArrayList<>();
        for (Player t : player_List) {
            if(position.equalsIgnoreCase(t.getPosition()))
            {
                newplayerlist.add(t);
            }
        }
        return newplayerlist;
    }

    public static List<Player> SearchingCountry(String country, List<Player> player_List) {
        List<Player> newplayerlist = new ArrayList<>();
        for (Player t : player_List) {
            if(country.equalsIgnoreCase(t.getCountry()))
            {
                newplayerlist.add(t);
            }
        }
        return newplayerlist;
    }

    public static List<Player> SearchingSalaryRange(Double amount1, Double amount2, List<Player> player_List) {
        List<Player> newplayerlist = new ArrayList<>();
        for (Player t: player_List) {
            if (t.getWeeklySalary() >= amount1 && t.getWeeklySalary() <= amount2)
            {
                newplayerlist.add(t);
            }
        }
        return newplayerlist;
    }

    public static List<Player> SearchingMAxAge(List<Player> player_List) {
        List<Player> newplayerlist = new ArrayList<>();
        int maxage = 0;
        int index = -1;
        Player p;
        for(int i = 0; i<player_List.size(); i++) {
            p = player_List.get(i);
            if(p.getAge() >= maxage)
            {
                index = i;
                maxage = p.getAge();
            }
        }

        if(index != -1){
            for (Player t: player_List) {
                if(t.getAge() >= maxage){
                newplayerlist.add(t);}
            }
        }
        return newplayerlist;
    }

    public static List<Player> SearchingMAxHeight(List<Player> player_List) {
        List<Player> newplayerlist = new ArrayList<>();
         double  maxheight = 0.0;
        int index = -1;
        Player p;
        for(int i = 0; i<player_List.size(); i++) {
            p = player_List.get(i);
            if(p.getHeight() >= maxheight)
            {
                index = i;
                maxheight = p.getHeight();
            }
        }
        if(index != -1){
            for (Player t: player_List) {
                if(t.getHeight() >= maxheight){
                    newplayerlist.add(t);}
            }
        }
        return newplayerlist;
    }

    public static List<Player> SearchingMAxSalary(List<Player> player_List) {
        List<Player> newplayerlist = new ArrayList<>();
        double  maxsalary = 0.0;
        int index = -1;
        Player p;
        for(int i = 0; i<player_List.size(); i++) {
            p = player_List.get(i);
            if(p.getWeeklySalary() >= maxsalary)
            {
                index = i;
                maxsalary = p.getWeeklySalary();
            }
        }
        if(index != -1){
            for (Player t: player_List) {
                if(t.getWeeklySalary() >= maxsalary){
                    newplayerlist.add(t);}
            }
        }
        return newplayerlist;
    }

    public static Double SearchTotalSalary(List<Player> player_List) {
        double ts = 0.0;
        for (int i = 0;i < player_List.size(); i++) {
            Player t = player_List.get(i);
                double yearlysalary = t.getWeeklySalary()*52.0;
                ts += yearlysalary;
        }
        return ts;
    }
}
