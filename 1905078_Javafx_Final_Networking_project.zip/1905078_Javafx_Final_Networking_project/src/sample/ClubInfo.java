package sample;

import com.sun.javafx.text.ScriptMapper;
import dto.PlayerInfo;
import javafx.animation.RotateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;

public class ClubInfo implements Initializable {


    @FXML private Circle c1;
    @FXML private Circle c2;
    @FXML private Circle c3;
    @FXML private Circle c4;
    @FXML private Circle c5;
    @FXML private Circle c6;

    String clb;
    public void ListShow(ActionEvent event) throws Exception {
        //main.ShowTable(main.str);

    }
    private Main main;
    public void setMain(Main main) {
        this.main = main;
    }

    @FXML
    void BackLogin(ActionEvent event) throws IOException {
        main.showLogin();
    }

    String cl;
    public void init(String clubname) {
        cl = clubname;
    }
    public String getCl() {
        return cl;
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setRotate(c1,true,360,32);
        setRotate(c2,true,354,37);
        setRotate(c3,true,345,18);
        setRotate(c4,true,330,23);
        setRotate(c5,true,250,43);
        setRotate(c6,true,223,45);
    }

    private void setRotate(Circle c,boolean reverse,int angle,int duration) {
        RotateTransition rotateTransition = new RotateTransition(Duration.seconds(duration),c);
        rotateTransition.setAutoReverse(reverse);
        rotateTransition.setByAngle(angle);
        rotateTransition.setDelay(Duration.seconds(0));
        rotateTransition.setRate(3);
        rotateTransition.setCycleCount(18);
        rotateTransition.play();
    }
}
