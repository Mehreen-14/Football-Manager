package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

public class WelcomePage {

    private Main main;
    @FXML
    private Button welcomebutton;

    @FXML
    private Text welcome;


    @FXML
    void WelcomeButton(ActionEvent event) throws Exception {
        try {
            main.showLogin();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    void setMain(Main main) {
        this.main = main;
    }

}
