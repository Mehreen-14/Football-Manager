package sample;

import javafx.beans.property.*;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import java.io.Serializable;


public class Player implements Serializable {
    /*private transient SimpleStringProperty playername;
    private transient SimpleStringProperty countryname;
    private transient SimpleStringProperty club_name;
    private transient SimpleIntegerProperty age;
    private transient SimpleDoubleProperty height;
    private transient SimpleStringProperty position;
    private transient SimpleIntegerProperty number;
    private transient SimpleDoubleProperty weeklysalary;
    private transient Button button;*/

    private String playername;
    private String countryname;
    private String club_name;
    private int age;
    private double height;
    private String position;
    private int number;
    private double weeklysalary;
    Player(String Name, String country, int age, double height, String clubname, String position, int number, double salary) {

        playername = Name;
        countryname = country;
        this.age = age;
        this.height = height;
        this.club_name = clubname;
        this.position = position;
        this.number = number;
        this.weeklysalary = salary;
    }

    public Player() {

    }
    public String getName() {
        return playername;
    }

    public void setName(String name) {
        this.playername=name;
    }

    public String getCountry() {
        return countryname;
    }

    public void setCountry(String country) {
        this.countryname=country;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age=age;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height=height;
    }

    public String getC_Name() {
        return club_name;
    }

    public void setC_name(String club) {
        this.club_name=club;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position=position;
    }

    public int getNum() {
        return number;
    }

    public void setNum(int number) {
        this.number=number;
    }

    public double getWeeklySalary() {
        return weeklysalary;
    }

    public void setWeeklySalary(double weeklySalary) {
        this.weeklysalary=weeklySalary;
    }


    public String toString() {
        return getName()+ ", " + getCountry() + ", " + getAge() + ", " + getHeight() + ", " + getC_Name() + ", " + getPosition() + ", " + getNum() + ", " + getWeeklySalary();
    }
}

