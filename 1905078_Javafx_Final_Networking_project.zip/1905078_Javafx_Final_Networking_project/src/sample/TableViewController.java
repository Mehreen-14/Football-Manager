package sample;

import dto.PlayerSell;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.LinkedTransferQueue;

public class TableViewController implements Initializable {

    private Main main;
    private static List<Player> ClubPlayer_List = new ArrayList<Player>();
    private static List<Player> player_List;

    @FXML
    private Button pname;
    @FXML
    private Button addplayer;
    @FXML
    private TableView<Player> tableview;

    @FXML
    private TableColumn<Player, String> countrycol;

    @FXML
    private TableColumn<Player, Integer> numbercol;

    @FXML
    private TableColumn<Player, Integer> agecol;

    @FXML
    private TableColumn<Player, Double> salarycol;

    @FXML
    private TableColumn<Player, String > clubcol;

    @FXML
    private TableColumn<Player, String> positioncol;

    @FXML
    private TableColumn<Player, Double> heightcol;

    @FXML
    private TableColumn<Player, String> playernamecol;

    @FXML
    private Label label;

    @FXML
    private ImageView search;
    @FXML
    private ImageView searchback;
    @FXML
    private AnchorPane slider;

    public String string;

    @FXML
    private  Label enter;
    @FXML
    private TextField textfield;
    @FXML
    private Button show;
    @FXML
    private Button backtable;

    @FXML
    private Label am1;
    @FXML
    private Label am2;
    @FXML
    private TextField amtext1;
    @FXML
    private TextField amtext2;
    @FXML
    private Label totalsalaryshow;
    @FXML
    private Label showlabel;

    @FXML
    private Label plname;
    @FXML
    private Label cname;
    @FXML
    private Label ageinput;
    @FXML
    private Label plheight;
    @FXML
    private Label plposition;
    @FXML
    private Label plnumber;
    @FXML
    private Label plsalary;

    @FXML
    private TextField aplayer;
    @FXML
    private TextField acountry;
    @FXML
    private TextField aage;
    @FXML
    private TextField aheight;
    @FXML
    private TextField aposition;
    @FXML
    private TextField anumber;
    @FXML
    private TextField asalary;
    @FXML
    private Button confirm;
    @FXML
    String name;
    void init(String msg) throws Exception {
        label.setText(msg);
        name = msg;
        ////*************////
        /*player_List = FileWorks.readFromFile();
        for (Player p : player_List) {
            if (msg.equalsIgnoreCase(p.getC_Name())) {
                ClubPlayer_List.add(p);
            }
        }*/
        ClubPlayer_List = Main.getPlayerList();
        string = msg;
        enter.setVisible(false);
        textfield.setVisible(false);
        show.setVisible(false);
        backtable.setVisible(false);
        am1.setVisible(false);
        am2.setVisible(false);
        amtext1.setVisible(false);
        amtext2.setVisible(false);
        totalsalaryshow.setVisible(false);
        showlabel.setVisible(false);
    }

    void setMain(Main main) {
        this.main = main;
    }

    ObservableList<Player> players;

    private boolean init = true;

    private void initializeColumns() throws Exception {

        playernamecol.setCellValueFactory(new PropertyValueFactory<>("Name"));

        countrycol.setCellValueFactory(new PropertyValueFactory<>("Country"));

        clubcol.setCellValueFactory(new PropertyValueFactory<>("C_Name"));

        agecol.setCellValueFactory(new PropertyValueFactory<>("Age"));

        heightcol.setCellValueFactory(new PropertyValueFactory<>("Height"));

        positioncol.setCellValueFactory(new PropertyValueFactory<>("Position"));

        numbercol.setCellValueFactory(new PropertyValueFactory<>("Num"));

        salarycol.setCellValueFactory(new PropertyValueFactory<>("WeeklySalary"));
    }

    public void load() throws Exception {
        if (init) {
            initializeColumns();
            init = false;
        }

     players = FXCollections.observableArrayList(ClubPlayer_List);

        tableview.setEditable(true);
        tableview.setItems(players);
    }
    public String msg;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        tableview.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        slider.setTranslateX(-176);
        search.setOnMouseClicked(mouseEvent -> {
            TranslateTransition slide = new TranslateTransition();
            slide.setDuration(Duration.seconds(0.4));
            slide.setNode(slider);

            slide.setToX(0);
            slide.play();

            slider.setTranslateX(-176);

            slide.setOnFinished((ActionEvent e)->{
                search.setVisible(false);
                searchback.setVisible(true);
            });
        });

        searchback.setOnMouseClicked(mouseEvent -> {
            TranslateTransition slide = new TranslateTransition();
            slide.setDuration(Duration.seconds(0.4));
            slide.setNode(slider);

            slide.setToX(-176);
            slide.play();

            slider.setTranslateX(0);

            slide.setOnFinished((ActionEvent e)->{
                search.setVisible(true);
                searchback.setVisible(false);
            });
        });
    }

    public void searchname(ActionEvent event) throws IOException {
        enter.setText("Enter Player Name : ");
        enter.setVisible(true);
        textfield.setVisible(true);
        show.setVisible(true);
        backtable.setVisible(true);
        am1.setVisible(false);
        am2.setVisible(false);
        amtext1.setVisible(false);
        amtext2.setVisible(false);

        show.setOnAction(event1 -> {
            List<Player> searchPlayers = new ArrayList<>();
            String player = textfield.getText();
            searchPlayers=SeachMethods.SearchingPlayerName(player,ClubPlayer_List);
            players = FXCollections.observableArrayList(searchPlayers);

            tableview.setEditable(true);
            tableview.setItems(players);
            textfield.clear();
        });
        backtable.setOnAction(event1 -> {
            players = FXCollections.observableArrayList(ClubPlayer_List);
            tableview.setEditable(true);
            tableview.setItems(players);
        });
    }


    public void ShowInfo(ActionEvent event) {
    }

    public void searchposition(ActionEvent event) {
        enter.setText("Enter Position : ");
        enter.setVisible(true);
        textfield.setVisible(true);
        show.setVisible(true);
        backtable.setVisible(true);
        am1.setVisible(false);
        am2.setVisible(false);
        amtext1.setVisible(false);
        amtext2.setVisible(false);


        show.setOnAction(event1 -> {
            List<Player> seachposition = new ArrayList<>();
            String position = textfield.getText();
            seachposition=SeachMethods.SearchingPosition(position,ClubPlayer_List);
            players = FXCollections.observableArrayList(seachposition);

            tableview.setEditable(true);
            tableview.setItems(players);
            textfield.clear();
        });
        backtable.setOnAction(event1 -> {
            players = FXCollections.observableArrayList(ClubPlayer_List);
            tableview.setEditable(true);
            tableview.setItems(players);
        });
    }

    public void backtomaintable(ActionEvent event) {

    }

    public void searchcountry(ActionEvent event) {
        enter.setText("Enter Country Name : ");
        enter.setVisible(true);
        textfield.setVisible(true);
        show.setVisible(true);
        backtable.setVisible(true);
        am1.setVisible(false);
        am2.setVisible(false);
        amtext1.setVisible(false);
        amtext2.setVisible(false);

        show.setOnAction(event1 -> {
            List<Player> seachcountry = new ArrayList<>();
            String country = textfield.getText();
            seachcountry=SeachMethods.SearchingCountry(country,ClubPlayer_List);
            players = FXCollections.observableArrayList(seachcountry);

            tableview.setEditable(true);
            tableview.setItems(players);
            textfield.clear();
        });
        backtable.setOnAction(event1 -> {
            players = FXCollections.observableArrayList(ClubPlayer_List);
            tableview.setEditable(true);
            tableview.setItems(players);
        });
    }

    public void RangeSearch(ActionEvent event) {
        enter.setVisible(false);
        textfield.setVisible(false);
        am1.setVisible(true);
        am2.setVisible(true);
        amtext1.setVisible(true);
        amtext2.setVisible(true);
        show.setVisible(true);
        backtable.setVisible(true);

        show.setOnAction(event1 -> {
            List<Player> seachSalaryRange = new ArrayList<>();
            String amount1 = amtext1.getText();
            String amount2 = amtext2.getText();
            try {
                Double salary1 = Double.parseDouble(amount1);
                Double salary2 = Double.parseDouble(amount2);
                seachSalaryRange = SeachMethods.SearchingSalaryRange(salary1, salary2, ClubPlayer_List);
                players = FXCollections.observableArrayList(seachSalaryRange);

                tableview.setEditable(true);
                tableview.setItems(players);
                amtext1.clear();
                amtext2.clear();
            }
            catch (Exception e) {
                amtext1.clear();
                amtext2.clear();
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("ERROR!!");
                alert.setHeaderText("Wrong Info");
                alert.setContentText("Salary Should be Double type!!");
                alert.showAndWait();
            }
        });
        backtable.setOnAction(event1 -> {
            players = FXCollections.observableArrayList(ClubPlayer_List);
            tableview.setEditable(true);
            tableview.setItems(players);
        });
    }

    public void MaxAgeSearch(ActionEvent event) {
        enter.setVisible(false);
        textfield.setVisible(false);
        am1.setVisible(false);
        am2.setVisible(false);
        amtext1.setVisible(false);
        amtext2.setVisible(false);
        show.setVisible(true);
        backtable.setVisible(true);


        show.setOnAction(event1 -> {
            List<Player> searchMaxAge = new ArrayList<>();
            searchMaxAge=SeachMethods.SearchingMAxAge(ClubPlayer_List);
            players = FXCollections.observableArrayList(searchMaxAge);

            tableview.setEditable(true);
            tableview.setItems(players);
        });
        backtable.setOnAction(event1 -> {
            players = FXCollections.observableArrayList(ClubPlayer_List);
            tableview.setEditable(true);
            tableview.setItems(players);
        });
    }

    public void MaxHeightSearch(ActionEvent event) {
        enter.setVisible(false);
        textfield.setVisible(false);
        am1.setVisible(false);
        am2.setVisible(false);
        amtext1.setVisible(false);
        amtext2.setVisible(false);
        show.setVisible(true);
        backtable.setVisible(true);

        show.setOnAction(event1 -> {
            List<Player> searchMaxHeight = new ArrayList<>();
            searchMaxHeight=SeachMethods.SearchingMAxHeight(ClubPlayer_List);
            players = FXCollections.observableArrayList(searchMaxHeight);

            tableview.setEditable(true);
            tableview.setItems(players);
        });
        backtable.setOnAction(event1 -> {
            players = FXCollections.observableArrayList(ClubPlayer_List);
            tableview.setEditable(true);
            tableview.setItems(players);
        });
    }

    public void MaxSalarySearch(ActionEvent event) {
        enter.setVisible(false);
        textfield.setVisible(false);
        am1.setVisible(false);
        am2.setVisible(false);
        amtext1.setVisible(false);
        amtext2.setVisible(false);
        show.setVisible(true);
        backtable.setVisible(true);


        show.setOnAction(event1 -> {
            List<Player> searchMaxSalary = new ArrayList<>();
            searchMaxSalary=SeachMethods.SearchingMAxSalary(ClubPlayer_List);
            players = FXCollections.observableArrayList(searchMaxSalary);

            tableview.setEditable(true);
            tableview.setItems(players);
        });
        backtable.setOnAction(event1 -> {
            players = FXCollections.observableArrayList(ClubPlayer_List);
            tableview.setEditable(true);
            tableview.setItems(players);
        });

    }

    public void YearlySalarySearch(ActionEvent event) {
        totalsalaryshow.setVisible(true);
        showlabel.setVisible(true);
        show.setVisible(false);


        Double total_salary = SeachMethods.SearchTotalSalary(ClubPlayer_List);
        totalsalaryshow.setText(String.format("%.0f",total_salary));
    }

    public void CountrywisePlayerCount(ActionEvent event) throws Exception {
        main.ShowCountryTable(main.str,ClubPlayer_List);
       // ClubPlayer_List.clear();
    }

    public void LOGOUT(ActionEvent event) throws IOException {
        main.showLogin();
        ClubPlayer_List.clear();
    }
    @FXML
    private TextField sellingfield;

    @FXML
    private Button sellplayer;


    public void market(ActionEvent event) throws Exception {
       main.ShowMarketPlace(main.str);
    }

    public void Sell(ActionEvent event) throws IOException {
        Player player = tableview.getSelectionModel().getSelectedItem();
       try{
           ClubPlayer_List.remove(player);
           PlayerSell playerSell = new PlayerSell();
           playerSell.setPl(player);
           //playerSell.setPlayerList(ClubPlayer_List);
           main.getNetworkUtil().write(playerSell);
       } catch (IOException e) {
           e.printStackTrace();
       }
       players = FXCollections.observableArrayList(ClubPlayer_List);

       tableview.setEditable(true);
       tableview.setItems(players);
    }
}
