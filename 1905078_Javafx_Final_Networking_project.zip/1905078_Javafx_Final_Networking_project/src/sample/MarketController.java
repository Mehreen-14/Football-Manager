package sample;

import Server.Server;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.ArrayList;
import java.util.List;

public class MarketController {

    private static List<Player> MarketPlaceList = new ArrayList<>();
    @FXML
    private TableColumn<Player, Integer> numbercol;

    @FXML
    private TableColumn<Player, Integer> acol;

    @FXML
    private TableColumn<Player, String> ccol;

    @FXML
    private TableColumn<Player, Double> salarycol;

    @FXML
    private TableColumn<Player, String> playercol;

    @FXML
    private TableColumn<Player, String> positioncol;

    @FXML
    private TableColumn<Player, Double> heightcol;

    @FXML
    private TableView<Player> tableview2;

    private Main main;

    public void setMain(Main main) { this.main = main; }
    String clubname;

    void init(String clubname) {
        this.clubname = clubname;
        MarketPlaceList = Main.getPlayermList();
    }

    ObservableList<Player> Marketplayers;

    private boolean init = true;

    private void initializeColumns() throws Exception {

        playercol.setCellValueFactory(new PropertyValueFactory<>("Name"));

        ccol.setCellValueFactory(new PropertyValueFactory<>("Country"));

        acol.setCellValueFactory(new PropertyValueFactory<>("Age"));

        heightcol.setCellValueFactory(new PropertyValueFactory<>("Height"));

        positioncol.setCellValueFactory(new PropertyValueFactory<>("Position"));

        numbercol.setCellValueFactory(new PropertyValueFactory<>("Num"));

        salarycol.setCellValueFactory(new PropertyValueFactory<>("WeeklySalary"));
    }

    public void load() throws Exception {
        if (init) {
            initializeColumns();
            init = false;
        }

        Marketplayers = FXCollections.observableArrayList(MarketPlaceList);

        tableview2.setEditable(true);
        tableview2.setItems(Marketplayers);
    }

    @FXML
    void backtomaintable(ActionEvent event) throws Exception {
        main.ShowTable(clubname);
    }

    public void RefreshTable(ActionEvent event) throws Exception {
        MarketPlaceList = Main.getPlayermList();
        Marketplayers = FXCollections.observableArrayList(MarketPlaceList);
        tableview2.setEditable(true);
        tableview2.setItems(Marketplayers);
    }
}
