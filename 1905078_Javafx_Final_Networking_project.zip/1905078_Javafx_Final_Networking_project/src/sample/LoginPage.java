package sample;

import dto.PlayerInfo;
import javafx.animation.RotateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import org.w3c.dom.Text;
import util.LoginDTO;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginPage  implements Initializable {

    @FXML
    public TextField text;

    @FXML
    private PasswordField password;

    public String clubname;
    @FXML
    private Rectangle rec1;

    @FXML
    private Rectangle rec2;

    @FXML
    private Rectangle rec3;

    @FXML
    private Rectangle rec4;

    @FXML
    void LoginAction(ActionEvent event) throws IOException {
            String clubname = text.getText();
            String passwordText = password.getText();
            LoginDTO loginDTO = new LoginDTO();
            loginDTO.setUserName(clubname);
            loginDTO.setPassword(passwordText);

                try {
                    main.getNetworkUtil().write(loginDTO);
                    PlayerInfo playerInfo = new PlayerInfo();
                    playerInfo.setClubname(clubname);
                    main.getNetworkUtil().write(playerInfo);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            text.clear();
            password.clear();
    }
    private Main main;
    public void setMain(Main main) {
        this.main = main;
    }

    @FXML
    void resetAction(ActionEvent event) {
        text.setText(null);
        password.clear();
    }

    @FXML
    void BackAction(ActionEvent event) throws Exception {
        main.Show_welcome();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        RotateTransition rt = new RotateTransition();
        rt.setDelay(Duration.millis(30));
        rt.setNode(rec1);
        rt.setByAngle(360);
        rt.setCycleCount(300);
        rt.setAutoReverse(false);
        rt.play();

        RotateTransition rt2 = new RotateTransition();
        rt2.setDelay(Duration.millis(30));
        rt2.setNode(rec2);
        rt2.setByAngle(360);
        rt2.setCycleCount(300);
        rt2.setAutoReverse(false);
        rt2.play();

        RotateTransition rt3 = new RotateTransition();
        rt3.setDelay(Duration.millis(30));
        rt3.setNode(rec3);
        rt3.setByAngle(360);
        rt3.setCycleCount(300);
        rt3.setAutoReverse(false);
        rt3.play();

        RotateTransition rt4 = new RotateTransition();
        rt4.setDelay(Duration.millis(30));
        rt4.setNode(rec4);
        rt4.setByAngle(360);
        rt4.setCycleCount(300);
        rt4.setAutoReverse(false);
        rt4.play();
    }
}
