package dto;

import sample.Player;

import java.io.Serializable;
import java.util.List;

public class SellingResponse implements Serializable {

    public List<Player> SellList;


    public List<Player> setSellList(List<Player> sellList) {this.SellList = sellList;
        return sellList;
    }
    public List<Player> getSellList() {return this.SellList;}
}
