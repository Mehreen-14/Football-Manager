package dto;

import sample.Player;

import java.io.Serializable;
import java.util.List;

public class PlayerSell implements Serializable {
    Player pl;


    public void setPl(Player pl) { this.pl = pl;}
    public Player getPl() {return this.pl;}

}
