package dto;

import sample.Player;

import java.io.Serializable;
import java.util.List;

public class PlayerList implements Serializable {
    private  List<Player> Playerlist;

    public  List<Player> getPlayerlist() {
        return Playerlist;
    }

    public void setPlayerlist(List<Player> playerList) {
        Playerlist = playerList;
    }
}
