package dto;

import java.io.Serializable;

public class PlayerInfo implements Serializable {
    String clubname;
    public  void setClubname(String clubname) {
        this.clubname = clubname;
    }
    public String getClubname() {
        return this.clubname;
    }
}
