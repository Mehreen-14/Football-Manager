package Server;

import sample.FileWorks;
import sample.Player;
import util.NetworkUtil;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Server {

    private ServerSocket serverSocket;
    public HashMap<String, String> userMap;
    public static List<Player> players;
    public static List<Player> sellList = new ArrayList<>();

    Server() throws Exception {
        players = new ArrayList<>();
        players = FileWorks.readFromFile();
        userMap = new HashMap<>();
        userMap.put("Arsenal", "mehreen");
        userMap.put("Liverpool", "mehreen");
        userMap.put("Manchester United", "mehreen");
        userMap.put("Manchester City", "mehreen");
        userMap.put("Chelsea", "mehreen");
        try {
            serverSocket = new ServerSocket(22222);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                serve(clientSocket);
            }
        } catch (Exception e) {
            System.out.println("Server starts:" + e);
        }
    }

    public void serve(Socket clientSocket) throws IOException {
        NetworkUtil networkUtil = new NetworkUtil(clientSocket);
        new ReadThreadServer(userMap,networkUtil);
    }
    public static List<Player> getPlayers() {
        return players;
    }

    public static void setSellList(List<Player> List) { sellList = List;}

    public static List<Player> getSellList() { return sellList; }

    public static void main(String[] args) throws Exception {
        new Server();
    }
}
