package Server;

import dto.PlayerInfo;
import dto.PlayerList;
import dto.PlayerSell;
import dto.SellingResponse;
import sample.Main;
import sample.Player;
import util.LoginDTO;
import util.NetworkUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ReadThreadServer implements Runnable {
    private final Thread thr;
    private final NetworkUtil networkUtil;
    public HashMap<String, String> userMap;


    public ReadThreadServer(HashMap<String, String> map, NetworkUtil networkUtil) {
        this.userMap = map;
        this.networkUtil = networkUtil;
        this.thr = new Thread(this);
        thr.start();
    }

    public void run() {
        try {
            while (true) {
                Object o = networkUtil.read();
                if (o != null) {
                    if (o instanceof LoginDTO) {
                        LoginDTO loginDTO = (LoginDTO) o;
                        String password = userMap.get(loginDTO.getUserName());
                        loginDTO.setStatus(loginDTO.getPassword().equals(password));
                        networkUtil.write(loginDTO);

                    }
                    if(o instanceof PlayerInfo) {

                              String club = ((PlayerInfo) o).getClubname();
                              List<Player> ClubPlayerList = new ArrayList<>();
                              for (Player p : Server.getPlayers()) {
                                  if (p.getC_Name().equalsIgnoreCase(club)) {
                                      ClubPlayerList.add(p);
                                  }
                              }
                              PlayerList playerList = new PlayerList();
                              playerList.setPlayerlist(ClubPlayerList);
                              try {
                                  networkUtil.write(playerList);
                              } catch (IOException e) {
                                  e.printStackTrace();
                              }
                    }
                    if(o instanceof PlayerSell) {
                        Player pl = ((PlayerSell) o).getPl();
                        List<Player> MarketPlaceList = Server.getSellList();
                        MarketPlaceList.add(pl);
                        Server.setSellList(MarketPlaceList);

                        SellingResponse sellingResponse = new SellingResponse();
                        sellingResponse.setSellList(MarketPlaceList);
                        try {
                            networkUtil.write(sellingResponse);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                networkUtil.closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}



